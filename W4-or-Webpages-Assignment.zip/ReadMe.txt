=========== What's this site? ================

This site displays some information about me including my picture, name, school, major, email, and different social media I have

==============================================

====Explain what you did in the .html file=====

* Written the plain content that I knew I wanted
  - Header Title, Name, Major, School Email, Socials.
  - Organized information into their own sections using <div> tags
  - Gave the Email a "mail to" feature

* Added Footer Section
  - Credits and creation 

* Added images as Background Images and Normal images
  - Image of myself as the background for my Info
  - UAT logo image to represent my School Info
  - Adjusted the sizes and position of the images

* Debugged based on Validator results
  - html document needed lang attribute
  - gave images alts
  

==============================================



=== Requirements: ============================
{v} - Create a basic markup structure for an HTML document.

{v} - Add title (W4 Assignment: Web Pages), headings, text, background, some images, and other items using the elements discussed in the reading from our textbook.
      
{v} - Analyze browser presentation of HTML documents on various browsers.

{} - Use well formatted, easy-to-read, and commented code.

{v] - Design a user-friendly interface, including readable output, with the interface being self-explaining
==============================================